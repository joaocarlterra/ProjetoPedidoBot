# Modelo de Ata para Projeto - UNINOVE

[![CC BY-SA
4.0](https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg)](http://creativecommons.org/licenses/by-sa/4.0/)

Este é um template LaTeX para o desenvolvimento das Atas do Projeto Integrador.

## **Orientações**

Siga as orientações contidas no arquivo _Modelo de Ata.text_.

## Licença

Esta obra está licenciada com uma Licença [Creative Commons ShareAlike 4.0 Internacional](http://creativecommons.org/licenses/by-sa/4.0/).

[![CC BY-SA 4.0](https://licensebuttons.net/l/by-sa/4.0/88x31.png)](http://creativecommons.org/licenses/by-sa/4.0/)
